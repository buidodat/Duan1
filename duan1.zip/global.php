<?php
    $img_path="upload/";
    if(isset($_SESSION['taikhoan'])){
        $taikhoan =$_SESSION['taikhoan'];
    }
?>