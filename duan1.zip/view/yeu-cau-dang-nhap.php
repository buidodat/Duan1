<section class="product-single theme1 pt-60">
<div class="col-12">
      <div class="text-center">
        <h3 class="title mb-3">Bạn chưa đăng nhập</h3>
        <p class="text">
          Bạn phải đăng nhập mới sử dụng được chức năng này
        </p>
        <div style="margin:20px">
        <a href="index.php?act=dangnhap">
            <span class="btn btn-dark btn--xl mt-5 mt-sm-0" type="submit">
                Đăng nhập ngay
            </span>
        </a>
        </div>
    </div>
</div>
</section>
<?php 
    include "view/footer.php";
?>